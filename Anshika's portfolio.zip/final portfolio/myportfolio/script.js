document.addEventListener('DOMContentLoaded', () => {
    // Mobile Menu Toggle
    const mobileMenu = document.querySelector('.mobile-menu');
    const navMenu = document.querySelector('.nav-menu');
    mobileMenu.addEventListener('click', () => {
        navMenu.classList.toggle('show');
        mobileMenu.classList.toggle('active');
    });

    // Smooth Scroll for Nav Links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            window.scrollTo({
                top: targetSection.offsetTop - 70,
                behavior: 'smooth'
            });
            if (navMenu.classList.contains('show')) {
                navMenu.classList.remove('show');
                mobileMenu.classList.remove('active');
            }
        });
    });

    // Scroll to Top Button
    const scrollTopBtn = document.querySelector('.scroll-top');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollTopBtn.classList.add('show');
        } else {
            scrollTopBtn.classList.remove('show');
        }
    });
    scrollTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    document.addEventListener("DOMContentLoaded", function() {
    const textArray = ["Full Stack Developer", "Data Scientist", "AI Enthusiast", "Problem Solver"];
    let typingElement = document.querySelector(".typing-text");
    let index = 0;
    let charIndex = 0;

    function type() {
        if (charIndex < textArray[index].length) {
            typingElement.textContent += textArray[index].charAt(charIndex);
            charIndex++;
            setTimeout(type, 100);
        } else {
            setTimeout(erase, 1500);
        }
    }

    function erase() {
        if (charIndex > 0) {
            typingElement.textContent = textArray[index].substring(0, charIndex - 1);
            charIndex--;
            setTimeout(erase, 50);
        } else {
            index++;
            if (index >= textArray.length) index = 0;
            setTimeout(type, 500);
        }
    }

    type();
});
window.addEventListener("scroll", function() {
    const scrollBtn = document.querySelector(".scroll-top");
    if (window.scrollY > 300) {
        scrollBtn.style.opacity = "1";
        scrollBtn.style.visibility = "visible";
        scrollBtn.style.transform = "translateY(0)";
    } else {
        scrollBtn.style.opacity = "0";
        scrollBtn.style.visibility = "hidden";
        scrollBtn.style.transform = "translateY(20px)";
    }
});

document.querySelector(".scroll-top").addEventListener("click", function() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
});



    // Hero Section Animation on Load
    window.addEventListener('load', () => {
        setTimeout(() => {
            document.querySelector('.hero-content').classList.add('show');
            document.querySelector('.hero-overlay').style.display = 'none';
        }, 1500);
    });

    // Typing Animation
    const typingText = document.querySelector('.typing-text');
    const words = ['Full Stack Developer', 'Data Scientist', 'AI Enthusiast'];
    let wordIndex = 0;
    let charIndex = 0;
    let currentWord = '';
    let isDeleting = false;

    function type() {
        if (wordIndex >= words.length) wordIndex = 0;
        currentWord = words[wordIndex];

        if (isDeleting) {
            typingText.textContent = currentWord.substring(0, charIndex--);
            if (charIndex < 0) {
                isDeleting = false;
                wordIndex++;
                setTimeout(type, 500);
            } else {
                setTimeout(type, 50);
            }
        } else {
            typingText.textContent = currentWord.substring(0, charIndex++);
            if (charIndex > currentWord.length) {
                isDeleting = true;
                setTimeout(type, 1500);
            } else {
                setTimeout(type, 100);
            }
        }
    }
    setTimeout(type, 1000);

    // Skill Progress Animation
    const skillBars = document.querySelectorAll('.skill-bar .fill');
    const skillsSection = document.querySelector('#skills');
    let skillsAnimated = false;

    const animateSkills = () => {
        if (skillsAnimated) return;
        skillBars.forEach(bar => {
            const progress = bar.getAttribute('data-progress');
            bar.style.width = `${progress}%`;
        });
        skillsAnimated = true;
    };

    const skillsObserver = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
            animateSkills();
        }
    }, { threshold: 0.5 });

    skillsObserver.observe(skillsSection);

    // About Section Animation
    const aboutParagraphs = document.querySelectorAll('.about-text p');
    const aboutSection = document.querySelector('#about');
    let aboutAnimated = false;

    const animateAbout = () => {
        if (aboutAnimated) return;
        aboutParagraphs.forEach(paragraph => {
            paragraph.classList.add('animate__fadeInUp');
        });
        aboutAnimated = true;
    };

    const aboutObserver = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
            animateAbout();
        }
    }, { threshold: 0.3 });

    aboutObserver.observe(aboutSection);

    // Timeline Animation
    const timelineItems = document.querySelectorAll('.timeline-item');
    const timelineObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const side = entry.target.getAttribute('data-side');
                entry.target.classList.add('animate__fadeIn' + (side === 'left' ? 'Left' : 'Right'));
            }
        });
    }, { threshold: 0.3 });

    timelineItems.forEach(item => timelineObserver.observe(item));

    // Social Work Animation
    const socialWorkCards = document.querySelectorAll('.social-work-card');
    const socialWorkObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate__flipInX');
            }
        });
    }, { threshold: 0.3 });

    socialWorkCards.forEach(card => socialWorkObserver.observe(card));

    // Scroll Animations with Intersection Observer
    const animateElements = document.querySelectorAll('.animate__animated:not(.timeline-item):not(.skill-category):not(.social-work-card):not(.about-text p)');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !entry.target.classList.contains('animate__fadeInUp') && !entry.target.classList.contains('animate__flipInX') && !entry.target.classList.contains('animate__fadeInLeft') && !entry.target.classList.contains('animate__fadeInRight') && !entry.target.classList.contains('animate__bounceIn')) {
                entry.target.classList.add('animate__fadeInUp');
            }
        });
    }, { threshold: 0.2 });

    animateElements.forEach(element => observer.observe(element));
});